import React, { useRef, useState } from 'react';
import DatePicker from './components/DatePicker';
import "./Css/StatsParDate.css";

export default function StatsParDate() {
  const datePickerRef = useRef(null);
  const [selectedDate, setSelectedDate] = useState(null);

  const handleButtonClick = () => {
    const date = datePickerRef.current.getSelectedDate();
    
    if(date.day!="" && date.month!=""  && date.year!="" ){console.log(date.day);
        console.log(date.month);setSelectedDate(date);
    }
  };
  const handleButtonClick2 = () => {
    setSelectedDate(null);
  };

  return (
    <div className='Containe'>
      {selectedDate ? (
        <div className='SelectedDateContainer'>
          <p> Date: {selectedDate.day}-{selectedDate.month}-{selectedDate.year}</p>
         
         
         {/* travail */}
         
         
         
         
         
         
         
          <button className='B_recherche' onClick={handleButtonClick2}>choisir autre date</button>
        </div>
      ) : (
        <div className='NoDateSelectedContainer'>
          <DatePicker ref={datePickerRef} />
          <button onClick={handleButtonClick} className='B_recherche'>recherche</button>
        </div>
      )}
    </div>
  );
}
