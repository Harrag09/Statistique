import React from "react";

const Blank = () => {
  return <div>PAGE 1</div>;
};

export default Blank;
