export { default as images } from "./images";
export { default as colors } from "./colors";
export { default as data } from "./data";
