const images = {
  profil: require("../assets/images/profil.jpg"),
  img1: require("../assets/images/logo.png"),
};

export default images;
